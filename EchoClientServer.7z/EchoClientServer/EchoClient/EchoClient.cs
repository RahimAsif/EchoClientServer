﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
namespace EchoClient
{
    class EchoClient
    {
        TcpClient client;
        private string IPAddress;
        private int portNumber;
        StreamWriter writer;
        StreamReader reader;

        public EchoClient(string IP, int port)
        {
            this.IPAddress = IP;
            this.portNumber = port;
        }

        public void Start()
        {
            Console.WriteLine("Starting client...");
            this.client = new TcpClient(this.IPAddress, this.portNumber);
            NetworkStream stream = client.GetStream();
            this.reader = new StreamReader(stream, Encoding.UTF8);
            this.writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
        }

        public void Run()
        {
            while (true)
            {
                Console.Write("Enter text to send: ");
                string lineToSend = Console.ReadLine();

                if (lineToSend.Trim() == "")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Sending to server: " + lineToSend);

                    foreach (char ch in lineToSend)
                    {
                        this.writer.Write(ch);
                    }
                    string endl = System.Environment.NewLine;
                    foreach(char ch in endl)
                    {
                        this.writer.Write((char)ch);
                    }

                    // this.writer.Write(lineToSend);
                    // string lineReceived = this.reader.ReadToEnd();
                    // Console.WriteLine(string.Format("Received from server: {0}", lineReceived));
                    Console.WriteLine("-------------------");
                }
            }

            this.client.Client.Close();
            this.client.Close();
        }
    }
}
