﻿using System.Net;

namespace EchoServer
{
    class Program
    {
        static void Main(string[] args)
        {
            EchoServer s = new EchoServer(IPAddress.Loopback, 1234);
            s.Start();
            s.Run();
        }
    }
}
