﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Diagnostics;


namespace EchoServer
{
    public class ClientMessage
    {
        public const int MAX_MSG_SIZE = 512;
        public const int END_OF_MSG_CHAR = 10;

        private int msgLength;
        private int clientID;
        private byte[] message;

        public ClientMessage(int clientID, char[] message, int msgLength)
        {
            this.clientID = clientID;
            this.message = new byte[msgLength];
            this.msgLength = msgLength;

            for (int i = 0; i < msgLength; i++)
            {
                this.message[i] = (byte) message[i];                
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("{");
            for (int i = 0; i < this.msgLength; i++)
            {
                sb.Append(this.message[i]);
                if (i < this.msgLength - 1)
                {
                    sb.Append(',');
                }
            }
            sb.Append("}");

            return sb.ToString();
        }
    }

    public class EchoServer
    {
        TcpListener tcpListener;
        private IPAddress ipAddress;
        private int portNumber;
        private static int nextClientID;
        Dictionary<System.Net.EndPoint, int> clientConnections;
        Queue<ClientMessage> receivedMsgQueue;


        static EchoServer()
        {
            EchoServer.nextClientID = 1;
        }

        public EchoServer(IPAddress ip, int port)
        {
            this.ipAddress = ip;
            this.portNumber = port;
        }

        public void Start()
        {
            Console.WriteLine("Starting echo server...");
            this.clientConnections = new Dictionary<System.Net.EndPoint, int>();
            this.receivedMsgQueue = new Queue<ClientMessage>();
            this.tcpListener = new TcpListener(this.ipAddress, this.portNumber);
            this.tcpListener.Start();
        }

        public void Run()
        {           
            while(true)
            {
                TcpClient client = this.tcpListener.AcceptTcpClient();
                Thread t = new Thread(ServiceIndividualClient);
                this.clientConnections.Add(client.Client.RemoteEndPoint, nextClientID++);
                t.Start(client);
            }                   
        }

        public void ServiceIndividualClient(object clientConnection)
        {
            TcpClient client = clientConnection as TcpClient;

            Console.WriteLine(string.Format("Connected to client #{0}", this.clientConnections[client.Client.RemoteEndPoint]));
            NetworkStream stream = client.GetStream();
            StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);

            int chunkSize;
            int msgIndex = 0;
            int maxBytesToRead = ClientMessage.MAX_MSG_SIZE - msgIndex;
            char[] msgBuffer = new char[ClientMessage.MAX_MSG_SIZE];
            while (true)
            {
                try
                {
                    chunkSize = reader.Read(msgBuffer, msgIndex, maxBytesToRead);
                    if(chunkSize > 0)
                    {
                        Debug.WriteLine(string.Format("ChunkSize = {0}", chunkSize));
                        msgIndex += chunkSize;
                        maxBytesToRead = ClientMessage.MAX_MSG_SIZE - msgIndex;
                        if (msgBuffer[msgIndex  - 1] == ClientMessage.END_OF_MSG_CHAR)
                        {
                            ClientMessage m = new ClientMessage(this.clientConnections[client.Client.RemoteEndPoint], msgBuffer, msgIndex);
                            this.receivedMsgQueue.Enqueue(m);
                            Debug.WriteLine(string.Format("Message Recv: {0}", m));

                            msgIndex = 0;
                        }
                        
                        if (msgIndex > ClientMessage.MAX_MSG_SIZE)
                        {
                            throw new OverflowException();
                        }
                    }                                                
                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.StackTrace);
                    Console.WriteLine(string.Format("Server saw disconnect from client #{0}", this.clientConnections[client.Client.RemoteEndPoint]));
                    client.Client.Close();
                    client.Close();
                    break;
                }
            }
        }
    }
}
