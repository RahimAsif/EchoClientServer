﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;


namespace EchoServer
{
    public class EchoServer
    {
        TcpListener tcpListener;
        private IPAddress ipAddress;
        private int portNumber;
        private static int nextClientID;
        Dictionary<System.Net.EndPoint, int> clientConnections;


        static EchoServer()
        {
            EchoServer.nextClientID = 1;
        }

        public EchoServer(IPAddress ip, int port)
        {
            this.ipAddress = ip;
            this.portNumber = port;
        }

        public void Start()
        {
            Console.WriteLine("Starting echo server...");
            this.clientConnections = new Dictionary<System.Net.EndPoint, int>();
            this.tcpListener = new TcpListener(this.ipAddress, this.portNumber);
            this.tcpListener.Start();
        }

        public void Run()
        {           
            while(true)
            {
                TcpClient client = this.tcpListener.AcceptTcpClient();
                Thread t = new Thread(ServiceIndividualClient);
                this.clientConnections.Add(client.Client.RemoteEndPoint, nextClientID++);
                t.Start(client);
            }                   
        }

        public void ServiceIndividualClient(object clientConnection)
        {
            TcpClient client = clientConnection as TcpClient;

            Console.WriteLine(string.Format("Connected to client #{0}", this.clientConnections[client.Client.RemoteEndPoint]));
            NetworkStream stream = client.GetStream();
            StreamWriter writer = new StreamWriter(stream, Encoding.ASCII) { AutoFlush = true };
            StreamReader reader = new StreamReader(stream, Encoding.ASCII);

            string inputLine = "";
            while (true)
            {
                try
                {
                    while (inputLine != null)
                    {
                        inputLine = reader.ReadLine();
                        if (inputLine.Trim() != "")
                        {
                            Console.WriteLine("-------------------");
                            Console.WriteLine(string.Format("Received from client: '{0}'", inputLine));
                            writer.WriteLine(inputLine);
                            Console.WriteLine(string.Format("Echoing string: '{0}'", inputLine));
                        }
                    }
                }
                catch
                {
                    Console.WriteLine(string.Format("Server saw disconnect from client #{0}", this.clientConnections[client.Client.RemoteEndPoint]));
                    client.Client.Close();
                    client.Close();
                    break;
                }
            }
        }
    }
}
