﻿using System.Net;

namespace EchoServer
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericServer s = new GenericServer(IPAddress.Loopback, 1234);
            s.Start();
            s.Run();
        }
    }
}
