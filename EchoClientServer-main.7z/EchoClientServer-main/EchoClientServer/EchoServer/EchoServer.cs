﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;


namespace EchoServer
{
    public abstract class TCPServer
    {
        private static UInt16 nextClientID;

        private IPAddress ipAddress;
        private int portNumber;
        private TcpListener tcpListener;
        protected Dictionary<UInt16, TcpClient> activeConnections;
        protected Queue<ClientMessage> receivedMsgsQueue;
        protected Queue<ClientMessage> processMsgsQueue;
        protected EventWaitHandle msgReceivedEvent;

        static TCPServer()
        {
            nextClientID = 1;
        }

        public TCPServer(IPAddress ipAddress, int portNumber)
        {
            this.ipAddress = ipAddress;
            this.portNumber = portNumber;
        }

        public void Start()
        {
            Console.WriteLine("Starting server...");
            this.msgReceivedEvent = new AutoResetEvent(false);
            this.receivedMsgsQueue = new Queue<ClientMessage>();            
            this.activeConnections = new Dictionary<UInt16, TcpClient>();

            // Start the process messages thread
            this.processMsgsQueue = new Queue<ClientMessage>();
            Thread processMessagesThread = new Thread(processReceivedMessages);
            processMessagesThread.Start();

            // Start waiting for clients to connect
            this.tcpListener = new TcpListener(this.ipAddress, this.portNumber);
            this.tcpListener.Start();
        }

        public void Run()
        {
            while (true)
            {
                // Wait for the client to connect
                TcpClient client = this.tcpListener.AcceptTcpClient();                
                // Add the client ID to the dictionary
                UInt16 clientID = nextClientID++;
                this.activeConnections.Add(clientID, client);

                Thread clientConnectionThread = new Thread(this.serviceIndividualClient);
                clientConnectionThread.Start(clientID);
            }      
        }

        protected void serviceIndividualClient(object clientID)
        {

            TcpClient client = this.activeConnections[(UInt16) clientID];
            NetworkStream stream = client.GetStream();           

            while (true)
            {
                try
                {
                    // Receive the next message
                    ClientMessage msg = receiveNextMessage((UInt16) clientID, stream);
                    receivedMsgsQueue.Enqueue(msg);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.StackTrace);
                    stream.Close();
                    client.Close();
                }
            }
        }

        protected void processReceivedMessages()
        {
            while (true)
            {
                this.msgReceivedEvent.WaitOne();
                lock (this.receivedMsgsQueue)
                {
                    while (this.receivedMsgsQueue.Count > 0)
                    {
                        this.processMsgsQueue.Enqueue(this.receivedMsgsQueue.Dequeue());
                    }
                }
                
            }
        }


        protected abstract ClientMessage receiveNextMessage(UInt16 clientID, Stream stream);


        public abstract class ClientMessage
        {

        }
    }


    public class EchoServerClientMessage : TCPServer.ClientMessage
    {
        public const int MAX_MSG_SIZE = 512;
        public const int END_OF_MSG_CHAR = 10;

        private int msgLength;
        private UInt16 clientID;
        private byte[] message;

        public EchoServerClientMessage(UInt16 clientID, byte[] message, int msgLength)
        {
            this.clientID = clientID;
            this.message = new byte[msgLength];
            this.msgLength = msgLength;

            int startIndex = 0;
            if (msgLength > 3)
            {
                if (message[0] == 239 &&
                    message[1] == 187 && message[2] == 191)
                {
                    startIndex = 3;
                    this.msgLength = this.msgLength - startIndex;
                }
            }

            for (int i = startIndex; i < msgLength; i++)
            {
                this.message[i - startIndex] = message[i];
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("{");
            for (int i = 0; i < this.msgLength; i++)
            {
                sb.Append(this.message[i]);
                if (i < this.msgLength - 1)
                {
                    sb.Append(',');
                }
            }
            sb.Append("}");

            return sb.ToString();
        }
    }


    public class GenericServer : TCPServer
    {
        public GenericServer(IPAddress ip, int portNumber)
            : base(ip, portNumber)
        {

        }

        protected override TCPServer.ClientMessage receiveNextMessage(UInt16 clientID, Stream stream)
        {
            EchoServerClientMessage m = null;

            int chunkSize;
            int msgIndex = 0;
            int maxBytesToRead = EchoServerClientMessage.MAX_MSG_SIZE - msgIndex;
            byte[] msgBuffer = new byte[EchoServerClientMessage.MAX_MSG_SIZE];
            bool completeMsgReceived = false;


            try
            {
                while (!completeMsgReceived)
                {
                    chunkSize = stream.Read(msgBuffer, msgIndex, maxBytesToRead);
                    if (chunkSize > 0)
                    {
                        Debug.WriteLine(string.Format("ChunkSize = {0}", chunkSize));
                        msgIndex += chunkSize;
                        maxBytesToRead = EchoServerClientMessage.MAX_MSG_SIZE - msgIndex;
                        if (msgBuffer[msgIndex - 1] == EchoServerClientMessage.END_OF_MSG_CHAR)
                        {
                            m = new EchoServerClientMessage(clientID, msgBuffer, msgIndex);
                            lock(this.receivedMsgsQueue)
                            {
                                this.receivedMsgsQueue.Enqueue(m);                                
                            }
                            this.msgReceivedEvent.Set();
                            Debug.WriteLine(string.Format("Message Recv: {0}", m));

                            completeMsgReceived = true;
                        }

                        if (msgIndex > EchoServerClientMessage.MAX_MSG_SIZE)
                        {
                            throw new OverflowException();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                m = null;
                Debug.WriteLine(ex.StackTrace);
            }

            return m;
        }
    }
}
