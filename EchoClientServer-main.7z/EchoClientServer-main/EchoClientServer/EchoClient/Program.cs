﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EchoClient
{
    class Program
    {
        static void Main(string[] args)
        {
            EchoClient client = new EchoClient("localhost", 1234);
            client.Start();
            client.Run();
        }
    }
}
